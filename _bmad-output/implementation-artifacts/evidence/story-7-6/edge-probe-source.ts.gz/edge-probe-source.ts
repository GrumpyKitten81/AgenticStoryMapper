import { snapshot, supply, op, id, createdAt } from '[REDACTED_HOME]/Projects/StoryMapper/packages/core/src/changesets/fixtures/remaining-operation-resolution-fixture.ts';
import { connectorConnectionSchema, remoteWorkItemSyncStateSchema } from '@storymapper/contracts';
import { resolveOperations, collectOperationConflicts } from '@storymapper/core';
function state() {
 const s=snapshot();
 s.connections=[connectorConnectionSchema.parse({id:id(50),projectId:id(1),provider:'github',name:'GitHub',authMode:'github-cli',owner:'org',repository:'repo',labelsAsAnnotations:true,createdAt,updatedAt:createdAt})];
 s.remoteWorkItemLinks=[{id:id(60),externalRefId:id(19),connectionId:id(50),provider:'github',cardId:id(3),remoteId:'1',remoteNumber:1,url:'https://github.com/org/repo/issues/1',syncState:'conflict',parentOverrideLocal:false,labels:[]}];
 s.syncRuns=[{id:id(61),projectId:id(1),storyMapId:id(2),connectionId:id(50),provider:'github',mode:'sync',status:'applied',summary:'Reviewed',createdAt}];
 s.syncConflicts=[{id:id(62),externalRefId:id(19),syncRunId:id(61),connectionId:id(50),cardId:id(3),remoteId:'1',field:'title',localValue:'Activity',remoteValue:'Remote',status:'open',createdAt}];
 return s;
}
const s=state();
const baseline=op({operationId:'baseline',op:'set',entity:'remoteWorkItemLink',before:s.remoteWorkItemLinks[0],after:remoteWorkItemSyncStateSchema.omit({id:true}).parse(s.remoteWorkItemLinks[0])});
const close=op({operationId:'close',op:'resolve',entity:'syncConflict',entityId:id(62),before:s.syncConflicts[0],after:{resolution:'remote'}});
const closed=resolveOperations(s,[baseline,close],supply());
console.log(JSON.stringify({probe:'baseline-only remote resolution',title:closed.state.cards[0].title,status:closed.state.syncConflicts[0].status}));
const a=state(); a.syncConflicts[0].field='labels'; a.annotations.push({...a.annotations[0],id:id(72),name:'Unassigned'});
const rename=op({entity:'annotation',op:'update',entityId:id(72),after:{name:'Risk'}});
console.log(JSON.stringify({probe:'unassigned duplicate rename',conflicts:collectOperationConflicts(a,[rename],supply()),names:resolveOperations(a,[rename],supply()).state.annotations.map(x=>x.name)}));
const w=state(); w.syncConflicts[0].field='status'; w.workflowStatuses[0].name=w.cards[0].status;
const color=op({entity:'workflowStatus',op:'update',entityId:id(11),after:{color:'#ffffff',definitionBefore:w.workflowStatuses[0],affectedCards:[{id:id(3),baseVersion:1}]}});
console.log(JSON.stringify({probe:'workflow color with valid review evidence',conflicts:collectOperationConflicts(w,[color],supply())}));
const c=state(); c.syncConflicts[0].field='labels';
const create=op({operationId:'create',entity:'annotation',op:'create',entityId:'new-local',after:{projectId:id(1),storyMapId:id(2),name:'New managed label'}});
const assign=op({operationId:'assign',entity:'cardAnnotation',entityId:id(3),op:'set',after:{cardId:id(3),annotationId:'new-local'}});
console.log(JSON.stringify({probe:'new managed Annotation alias assignment',conflicts:collectOperationConflicts(c,[create,assign],{...supply(),ids:{create:id(101),assign:id(102)}}),assigned:resolveOperations(c,[create,assign],{...supply(),ids:{create:id(101),assign:id(102)}}).state.cardAnnotations}));
