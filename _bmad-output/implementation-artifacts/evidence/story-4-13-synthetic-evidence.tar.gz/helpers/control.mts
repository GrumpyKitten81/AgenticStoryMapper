import { readFileSync, writeFileSync } from 'node:fs';
import { composeRecordedFiles, recordedFiles } from '[REDACTED_HOME]/Projects/StoryMapper/apps/server/src/fixtures/bmad-round-trip/composer.ts';
const root='/tmp/storymapper-4-13-browser';
const base='http://127.0.0.1:4317';
async function request(path:string, input?:unknown, method='POST') {
 const response=await fetch(base+path,{method:input===undefined?'GET':method,headers:{'Content-Type':'application/json'},body:input===undefined?undefined:JSON.stringify(input)});
 const data=await response.json(); return {status:response.status,data};
}
async function tool(name:string,input:unknown) {return request('/api/mcp/call',{name,input});}
const [command,number='1',recording='initial',flag='true']=process.argv.slice(2);
let sessions:any[]=[];
if(command==='setup') {
 for(let i=1;i<=5;i++) {
  const p=await request('/api/projects',{name:`4.13 simulation ${i}`}); if(p.status!==201)throw Error(JSON.stringify(p));
  const m=await request('/api/story-maps',{projectId:p.data.id,name:`Recorded BMad scenario ${i}`}); if(m.status!==201)throw Error(JSON.stringify(m));
  sessions.push({number:i,projectId:p.data.id,mapId:m.data.id,setupAt:new Date().toISOString()});
 }
 writeFileSync(root+'/sessions.json',JSON.stringify(sessions,null,2));console.log(JSON.stringify(sessions));
} else {
 sessions=JSON.parse(readFileSync(root+'/sessions.json','utf8'));const s=sessions[Number(number)-1];
 if(command==='publish') {
  const snapshot=(await tool('GetStoryMapSnapshot',{storyMapId:s.mapId})).data.data;
  const listed=(await tool('ListSourceDocuments',{projectId:s.projectId})).data.data.documents;
  const documents=[];for(const d of listed)documents.push((await tool('GetSourceDocument',{documentId:d.id})).data.data);
  const files=recordedFiles(recording as any);const owned=new Set<string>(s.owned??[]);
  const operations=composeRecordedFiles(s.projectId,snapshot,files,documents,owned);
  const start=new Date().toISOString();const result=await tool('SubmitChangeSet',{projectId:s.projectId,title:`Scenario ${number} ${recording}`,operations,apply:flag==='true'});
  writeFileSync(`${root}/s${number}-${recording}-${Date.now()}.json`,JSON.stringify({start,finish:new Date().toISOString(),files,operations,result},null,2));
  if(!s.firstPublishAt)s.firstPublishAt=start;s.last=result.data;
  writeFileSync(root+'/sessions.json',JSON.stringify(sessions,null,2));console.log(JSON.stringify({start,status:result.status,outcome:result.data.outcome,changeSetId:result.data.changeSetId,code:result.data.code,operations:operations.length}));
 } else if(command==='capture') {
  const snapshot=(await tool('GetStoryMapSnapshot',{storyMapId:s.mapId})).data.data;
  const activity=await request(`/api/activity?projectId=${s.projectId}`);
  const changesets=await request(`/api/changesets?projectId=${s.projectId}`);
  s.owned=snapshot.sourceLinks.filter((l:any)=>l.kind==='chunk').map((l:any)=>l.id);
  s.reviewedAt=new Date().toISOString();writeFileSync(`${root}/s${number}-capture-${Date.now()}.json`,JSON.stringify({at:s.reviewedAt,snapshot,activity,changesets},null,2));
  writeFileSync(root+'/sessions.json',JSON.stringify(sessions,null,2));console.log(JSON.stringify({number:s.number,at:s.reviewedAt,cards:snapshot.cards.length,refs:snapshot.externalRefs.length,links:snapshot.sourceLinks.length}));
 } else if(command==='tool') {console.log(JSON.stringify(await tool(recording,JSON.parse(flag))));}
}
