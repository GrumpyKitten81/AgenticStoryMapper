import {readFileSync,writeFileSync,readdirSync}from'node:fs';
const root='/tmp/storymapper-4-13-browser';
const initial=JSON.parse(readFileSync(root+'/'+readdirSync(root).find(x=>x.startsWith('s4-capture-'))));
const final=JSON.parse(readFileSync(root+'/s4-durable-proof.json'));
const preview=JSON.parse(readFileSync(root+'/s4-edited-preview.json'));
const initialSet=initial.changesets.data.changeSets.find(x=>x.id==='a8440a41-7aa7-4207-b27b-ac5c65e0add7');
const finalSet=final.changesets.changeSets.find(x=>x.id==='c8df812f-c56a-4605-b6f4-d39f9379324a');
const persisted=new Set([...final.snapshot.cards,...final.snapshot.releases,...final.snapshot.externalRefs,...final.snapshot.sourceLinks,...final.details.flatMap(d=>[d.document,...d.chunks])].map(x=>x.id));
const semanticCard=c=>Object.fromEntries(Object.entries(c).filter(([k])=>!['version','createdAt','updatedAt'].includes(k)));
const checks=[];
for(const result of initialSet.execution.operationResults){
 const op=initialSet.operations[result.index];let kept=result.entityIds.every(id=>persisted.has(id));let reason=kept?'All created domain identities retained':'Created identities intentionally replaced';
 if(op.entity==='card'){
  const before=initial.snapshot.cards.find(c=>c.id===result.entityIds[0]);const after=final.snapshot.cards.find(c=>c.id===result.entityIds[0]);
  kept=!!after&&JSON.stringify(semanticCard(before))===JSON.stringify(semanticCard(after));if(!kept)reason='Initial Card effect deliberately superseded by edited refresh';
 }
 checks.push({changeSetId:initialSet.id,operationId:result.operationId,kept,reason,entityIds:result.entityIds});
}
const changed=new Set(preview.operations.filter(o=>o.status==='changed').map(o=>o.operationId));
for(const result of finalSet.execution.operationResults.filter(r=>changed.has(r.operationId))){
 const op=finalSet.operations[result.index];let kept;
 if(op.op==='unlink')kept=!final.snapshot.sourceLinks.some(l=>l.id===op.entityId);
 else if(op.op==='archive')kept=final.snapshot.cards.find(c=>c.id===op.entityId)?.status==='archived';
 else kept=result.entityIds.every(id=>persisted.has(id));
 checks.push({changeSetId:finalSet.id,operationId:result.operationId,kept,reason:'Edited refresh durable effect',entityIds:result.entityIds});
}
const result={firstPublishAt:final.firstPublishAt,browserReviewedAt:final.browserReviewedAt,elapsedSeconds:final.elapsedSeconds,appliedDomainOperations:checks.length,keptDomainOperations:checks.filter(x=>x.kept).length,rawRetention:checks.filter(x=>x.kept).length/checks.length,unchangedProposalDomainEffects:0,editedRefreshUnchangedOperations:preview.operations.filter(o=>o.status==='unchanged').length,supersededEffects:checks.filter(x=>!x.kept),checks};
writeFileSync(root+'/s4-retention-proof.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));
