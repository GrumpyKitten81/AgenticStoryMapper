import {readFileSync,writeFileSync} from 'node:fs';
const root='/tmp/storymapper-4-13-browser';const sessions=JSON.parse(readFileSync(root+'/sessions.json'));
async function post(path,input){const r=await fetch('http://127.0.0.1:4317'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)});if(r.status!==201)throw Error(await r.text());return r.json();}
const p=await post('/api/projects',{name:'4.13 simulation 2 executable rerun'});const m=await post('/api/story-maps',{projectId:p.id,name:'Recorded BMad scenario 2 rerun'});
const s={number:6,scenario:2,attempt:'fresh-authorized',projectId:p.id,mapId:m.id,setupAt:new Date().toISOString()};sessions.push(s);writeFileSync(root+'/sessions.json',JSON.stringify(sessions,null,2));console.log(JSON.stringify(s));
